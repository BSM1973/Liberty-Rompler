#pragma once
#include <JuceHeader.h>
#include "BankLibrary.h"
#include "SampleEngine.h"

class LibertyRomplerAudioProcessor final : public juce::AudioProcessor {
public:
    LibertyRomplerAudioProcessor();
    ~LibertyRomplerAudioProcessor() override = default;
    const juce::String getName() const override { return "Liberty Rompler"; }
    void prepareToPlay(double sampleRate, int maximumExpectedSamplesPerBlock) override;
    void releaseResources() override {}
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    double getTailLengthSeconds() const override { return 2.0; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return currentPresetName; }
    void changeProgramName(int, const juce::String&) override {}
    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*, int) override;
    liberty::BankLibrary& getLibrary() { return library; }
    juce::MidiKeyboardState& getKeyboard() { return keyboard; }
    liberty::PerformanceControls& getControls() { return controls; }
    juce::Result selectPreset(const juce::String& bankId, const juce::String& presetId);
    juce::String getSelectedBankId() const { return currentBankId; }
    juce::String getSelectedPresetId() const { return currentPresetId; }
    juce::String getSelectedPresetName() const { return currentPresetName; }
private:
    juce::AudioFormatManager formats;
    liberty::MappedSynthesiser synth;
    juce::MidiKeyboardState keyboard;
    liberty::BankLibrary library;
    liberty::PerformanceControls controls;
    juce::String currentBankId, currentPresetId, currentPresetName;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(LibertyRomplerAudioProcessor)
};
