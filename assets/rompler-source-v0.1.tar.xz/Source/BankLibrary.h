#pragma once
#include <JuceHeader.h>
#include <vector>

namespace liberty {
struct ZoneDescriptor {
    juce::File file;
    int rootNote = 60, lowNote = 0, highNote = 127;
    int lowVelocity = 1, highVelocity = 127;
    int loopStart = -1, loopEnd = -1; // sample frames, -1 disables loop
    float gain = 1.0f;
};
struct PresetDescriptor {
    juce::String id, name, category, bankId, bankName;
    std::vector<ZoneDescriptor> zones;
};
struct BankDescriptor {
    juce::String id, name, version;
    juce::File folder;
    std::vector<PresetDescriptor> presets;
};
class BankLibrary {
public:
    explicit BankLibrary(juce::File directory);
    void rescan();
    const std::vector<BankDescriptor>& getBanks() const { return banks; }
    juce::File getDirectory() const { return bankRoot; }
    const juce::StringArray& getWarnings() const { return warnings; }
    const PresetDescriptor* find(const juce::String& bank, const juce::String& preset) const;
    static juce::File defaultDirectory();
private:
    juce::File bankRoot;
    std::vector<BankDescriptor> banks;
    juce::StringArray warnings;
};
} // namespace liberty
