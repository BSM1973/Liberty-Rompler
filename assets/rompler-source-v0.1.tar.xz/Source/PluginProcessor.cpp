#include "PluginProcessor.h"
#include "PluginEditor.h"

LibertyRomplerAudioProcessor::LibertyRomplerAudioProcessor()
    : juce::AudioProcessor(BusesProperties().withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      library(liberty::BankLibrary::defaultDirectory()) {
    formats.registerBasicFormats();
    for (int i = 0; i < 48; ++i) synth.addVoice(new liberty::SampleVoice(controls));
    if (!library.getBanks().empty() && !library.getBanks()[0].presets.empty()) {
        const auto& bank = library.getBanks()[0];
        selectPreset(bank.id, bank.presets[0].id);
    }
}

void LibertyRomplerAudioProcessor::prepareToPlay(double rate, int) {
    synth.setCurrentPlaybackSampleRate(rate);
}
bool LibertyRomplerAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const {
    return layouts.getMainOutputChannelSet() == juce::AudioChannelSet::stereo();
}
void LibertyRomplerAudioProcessor::processBlock(juce::AudioBuffer<float>& audio, juce::MidiBuffer& midi) {
    juce::ScopedNoDenormals noDenormals;
    audio.clear();
    keyboard.processNextMidiBuffer(midi, 0, audio.getNumSamples(), true);
    synth.renderNextBlock(audio, midi, 0, audio.getNumSamples());
    audio.applyGain(controls.masterGain.load(std::memory_order_relaxed));
}
juce::Result LibertyRomplerAudioProcessor::selectPreset(const juce::String& bankId,
                                                        const juce::String& presetId) {
    const auto* p = library.find(bankId, presetId);
    if (!p) return juce::Result::fail("Preset ou banque introuvable.");

    // Phase 1: prepare sample data BEFORE touching the live synthesiser.
    juce::ReferenceCountedArray<juce::SynthesiserSound> pending;
    for (const auto& zone : p->zones) {
        auto reader = std::unique_ptr<juce::AudioFormatReader>(formats.createReaderFor(zone.file));
        if (!reader) return juce::Result::fail("Fichier audio illisible : " + zone.file.getFileName());
        auto* sound = new liberty::MappedSampleSound(zone, *reader);
        if (!sound->isLoaded()) { delete sound; return juce::Result::fail("Sample invalide : " + zone.file.getFileName()); }
        pending.add(sound);
    }
    // Phase 2: swap sounds. JUCE's Synthesiser synchronizes its internal state.
    // A lock-free program-swap queue is required before final commercial release.
    synth.allNotesOff(0, false);
    synth.clearSounds();
    for (auto* sound : pending) synth.addSound(sound);
    currentBankId = bankId;
    currentPresetId = presetId;
    currentPresetName = p->name;
    updateHostDisplay(juce::AudioProcessor::ChangeDetails().withProgramChanged(true));
    return juce::Result::ok();
}

void LibertyRomplerAudioProcessor::getStateInformation(juce::MemoryBlock& dest) {
    auto state = juce::var(new juce::DynamicObject());
    auto* object = state.getDynamicObject();
    object->setProperty("bank", currentBankId);
    object->setProperty("preset", currentPresetId);
    object->setProperty("gain", controls.masterGain.load());
    object->setProperty("attack", controls.attackSeconds.load());
    object->setProperty("release", controls.releaseSeconds.load());
    const auto json = juce::JSON::toString(state);
    dest.replaceAll(json.toRawUTF8(), (size_t)json.getNumBytesAsUTF8());
}
void LibertyRomplerAudioProcessor::setStateInformation(const void* data, int size) {
    if (size <= 0 || !data) return;
    const auto json = juce::String::fromUTF8((const char*)data, size);
    const auto state = juce::JSON::parse(json);
    if (auto* o = state.getDynamicObject()) {
        controls.masterGain = juce::jlimit(0.0f, 1.5f, (float)(double)o->getProperty("gain"));
        controls.attackSeconds = juce::jlimit(0.0f, 2.0f, (float)(double)o->getProperty("attack"));
        controls.releaseSeconds = juce::jlimit(0.02f, 5.0f, (float)(double)o->getProperty("release"));
        selectPreset(o->getProperty("bank").toString(), o->getProperty("preset").toString());
    }
}
juce::AudioProcessorEditor* LibertyRomplerAudioProcessor::createEditor() {
    return new LibertyRomplerAudioProcessorEditor(*this);
}
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() {
    return new LibertyRomplerAudioProcessor();
}
