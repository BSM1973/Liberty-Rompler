#pragma once
#include "BankLibrary.h"
#include <atomic>

namespace liberty {
struct PerformanceControls {
    std::atomic<float> masterGain {0.75f};
    std::atomic<float> attackSeconds {0.008f};
    std::atomic<float> releaseSeconds {0.30f};
};

class MappedSampleSound final : public juce::SynthesiserSound {
public:
    MappedSampleSound(const ZoneDescriptor& zone, juce::AudioFormatReader& reader);
    bool appliesToNote(int midiNoteNumber) override;
    bool appliesToChannel(int) override { return true; }
    bool appliesToVelocity(float velocity) const;
    const juce::AudioBuffer<float>& getAudio() const { return data; }
    double getSourceSampleRate() const { return sourceRate; }
    int getRootNote() const { return rootNote; }
    int getLoopStart() const { return loopStart; }
    int getLoopEnd() const { return loopEnd; }
    float getGain() const { return gain; }
    bool isLoaded() const { return data.getNumSamples() > 1; }
private:
    juce::AudioBuffer<float> data;
    double sourceRate = 44100.0;
    int rootNote, lowNote, highNote, lowVelocity, highVelocity;
    int loopStart, loopEnd;
    float gain;
};

// Unlike JUCE's default noteOn(), this does not stop an earlier velocity layer
// while starting another overlapping sound from the same preset.
class MappedSynthesiser final : public juce::Synthesiser {
public:
    void noteOn(int midiChannel, int midiNoteNumber, float velocity) override;
};

class SampleVoice final : public juce::SynthesiserVoice {
public:
    explicit SampleVoice(PerformanceControls& performance) : controls(performance) {}
    bool canPlaySound(juce::SynthesiserSound* sound) override;
    void startNote(int midiNoteNumber, float velocity, juce::SynthesiserSound* sound,
                   int currentPitchWheelPosition) override;
    void stopNote(float velocity, bool allowTailOff) override;
    void pitchWheelMoved(int value) override;
    void controllerMoved(int, int) override {}
    void renderNextBlock(juce::AudioBuffer<float>& outputBuffer,
                         int startSample, int numSamples) override;
private:
    PerformanceControls& controls;
    juce::ADSR envelope;
    double position = 0.0, ratio = 1.0;
    int note = 60, wheel = 8192;
    float velocityGain = 0.0f;
    void updatePitch();
};
} // namespace liberty
