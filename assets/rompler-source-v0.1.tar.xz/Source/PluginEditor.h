#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class LibertyRomplerAudioProcessorEditor final : public juce::AudioProcessorEditor,
                                                 private juce::ListBoxModel {
public:
    explicit LibertyRomplerAudioProcessorEditor(LibertyRomplerAudioProcessor&);
    ~LibertyRomplerAudioProcessorEditor() override = default;
    void paint(juce::Graphics&) override;
    void resized() override;
private:
    LibertyRomplerAudioProcessor& processor;
    juce::ComboBox bankSelector, categorySelector;
    juce::TextEditor searchField;
    juce::ListBox presetList;
    juce::TextButton rescanButton {"Actualiser"}, folderButton {"Dossier des banques"};
    juce::Label productLabel, sectionLabel, presetLabel, statusLabel;
    juce::Label gainLabel, attackLabel, releaseLabel;
    juce::Slider gainSlider, attackSlider, releaseSlider;
    juce::MidiKeyboardComponent keyboard;
    std::vector<int> visiblePresetIndices;
    juce::String category = "Toutes";
    int bankIndex = -1;
    int getNumRows() override;
    void paintListBoxItem(int row, juce::Graphics&, int width, int height, bool selected) override;
    void selectedRowsChanged(int row) override;
    void rebuildBankList();
    void rebuildCategoryList();
    void rebuildPresetList();
    void updatePresetInfo();
    void configureSlider(juce::Slider&, juce::Label&, const juce::String&, double, double, double);
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(LibertyRomplerAudioProcessorEditor)
};
