#include "SampleEngine.h"
#include <cmath>

namespace liberty {
MappedSampleSound::MappedSampleSound(const ZoneDescriptor& z, juce::AudioFormatReader& reader)
    : sourceRate(reader.sampleRate), rootNote(z.rootNote), lowNote(z.lowNote),
      highNote(z.highNote), lowVelocity(z.lowVelocity), highVelocity(z.highVelocity),
      loopStart(z.loopStart), loopEnd(z.loopEnd), gain(z.gain) {
    // Prototype memory cap: up to 20 seconds per sample zone.
    const auto count = (int)juce::jmin(reader.lengthInSamples,
                                      (juce::int64)(reader.sampleRate * 20.0));
    if (count < 2 || reader.numChannels < 1 || reader.numChannels > 2) return;
    data.setSize((int)reader.numChannels, count + 1);
    data.clear();
    if (!reader.read(&data, 0, count, 0, true, true)) data.setSize(0, 0);
    if (loopStart < 0 || loopEnd <= loopStart + 10 || loopEnd > count) {
        loopStart = -1;
        loopEnd = -1;
    }
}
bool MappedSampleSound::appliesToNote(int n) { return n >= lowNote && n <= highNote; }
bool MappedSampleSound::appliesToVelocity(float v) const {
    const int midiVelocity = juce::jlimit(1, 127, (int)std::round(v * 127.0f));
    return midiVelocity >= lowVelocity && midiVelocity <= highVelocity;
}
void MappedSynthesiser::noteOn(int channel, int noteNumber, float velocity) {
    const juce::ScopedLock sl(lock);
    // Stop currently held layers once, not once per matching zone.
    for (auto* voice : voices)
        if (voice->getCurrentlyPlayingNote() == noteNumber && voice->isPlayingChannel(channel))
            stopVoice(voice, 1.0f, true);
    for (auto* sound : sounds) {
        auto* mapped = dynamic_cast<MappedSampleSound*>(sound);
        if (mapped && mapped->appliesToChannel(channel) && mapped->appliesToNote(noteNumber)
            && mapped->appliesToVelocity(velocity)) {
            startVoice(findFreeVoice(sound, channel, noteNumber, isNoteStealingEnabled()),
                       sound, channel, noteNumber, velocity);
        }
    }
}
bool SampleVoice::canPlaySound(juce::SynthesiserSound* sound) {
    return dynamic_cast<MappedSampleSound*>(sound) != nullptr;
}
void SampleVoice::startNote(int midiNoteNumber, float velocity, juce::SynthesiserSound* sound, int pitchWheel) {
    auto* s = dynamic_cast<MappedSampleSound*>(sound);
    if (!s || !s->isLoaded() || !s->appliesToVelocity(velocity)) {
        clearCurrentNote();
        return;
    }
    note = midiNoteNumber;
    wheel = pitchWheel;
    position = 0;
    velocityGain = std::sqrt(juce::jlimit(0.0f, 1.0f, velocity)) * s->getGain();
    envelope.setSampleRate(juce::jmax(1.0, getSampleRate()));
    juce::ADSR::Parameters p;
    p.attack = controls.attackSeconds.load(std::memory_order_relaxed);
    p.decay = 0.05f;
    p.sustain = 1.0f;
    p.release = controls.releaseSeconds.load(std::memory_order_relaxed);
    envelope.setParameters(p);
    envelope.noteOn();
    updatePitch();
}
void SampleVoice::updatePitch() {
    auto* s = dynamic_cast<MappedSampleSound*>(getCurrentlyPlayingSound().get());
    if (!s) return;
    const double bend = ((double)wheel - 8192.0) / 8192.0 * 2.0; // +/- 2 semitones
    ratio = std::pow(2.0, ((double)(note - s->getRootNote()) + bend) / 12.0)
          * (s->getSourceSampleRate() / juce::jmax(1.0, getSampleRate()));
}
void SampleVoice::pitchWheelMoved(int value) { wheel = value; updatePitch(); }
void SampleVoice::stopNote(float, bool allowTailOff) {
    if (allowTailOff) envelope.noteOff();
    else { envelope.reset(); clearCurrentNote(); }
}
void SampleVoice::renderNextBlock(juce::AudioBuffer<float>& out, int start, int count) {
    auto* s = dynamic_cast<MappedSampleSound*>(getCurrentlyPlayingSound().get());
    if (!s || !s->isLoaded()) return;
    const auto& audio = s->getAudio();
    const int last = audio.getNumSamples() - 1;
    const int channels = juce::jmin(2, out.getNumChannels());
    for (int i = 0; i < count; ++i) {
        if (position >= last) { clearCurrentNote(); break; }
        const int frame = (int)position;
        const float mix = (float)(position - frame);
        const float amp = envelope.getNextSample() * velocityGain;
        for (int ch = 0; ch < channels; ++ch) {
            const int source = juce::jmin(ch, audio.getNumChannels() - 1);
            const auto* data = audio.getReadPointer(source);
            const float value = data[frame] + (data[frame + 1] - data[frame]) * mix;
            out.addSample(ch, start + i, value * amp);
        }
        position += ratio;
        if (s->getLoopStart() >= 0 && position >= s->getLoopEnd()) {
            const auto length = (double)(s->getLoopEnd() - s->getLoopStart());
            position = (double)s->getLoopStart() + std::fmod(position - s->getLoopStart(), length);
        }
        if (!envelope.isActive()) { clearCurrentNote(); break; }
    }
}
} // namespace liberty
