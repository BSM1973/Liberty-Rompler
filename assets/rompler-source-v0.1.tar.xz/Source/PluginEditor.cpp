#include "PluginEditor.h"

namespace {
const juce::Colour midnight {0xff111620};
const juce::Colour panel {0xff1c2430};
const juce::Colour panelLight {0xff273141};
const juce::Colour gold {0xffddae67};
const juce::Colour ice {0xffe1e8f2};
const juce::Colour muted {0xff93a0b0};
}

LibertyRomplerAudioProcessorEditor::LibertyRomplerAudioProcessorEditor(LibertyRomplerAudioProcessor& p)
    : juce::AudioProcessorEditor(p), processor(p),
      keyboard(processor.getKeyboard(), juce::MidiKeyboardComponent::horizontalKeyboard) {
    setSize(1024, 644);
    setResizable(true, true);
    setResizeLimits(880, 540, 1500, 900);
    getLookAndFeel().setColour(juce::ComboBox::backgroundColourId, panelLight);
    getLookAndFeel().setColour(juce::ComboBox::textColourId, ice);
    getLookAndFeel().setColour(juce::ComboBox::outlineColourId, juce::Colours::transparentBlack);
    getLookAndFeel().setColour(juce::TextEditor::backgroundColourId, panelLight);
    getLookAndFeel().setColour(juce::TextEditor::textColourId, ice);
    getLookAndFeel().setColour(juce::TextEditor::outlineColourId, juce::Colours::transparentBlack);
    getLookAndFeel().setColour(juce::Slider::rotarySliderFillColourId, gold);
    getLookAndFeel().setColour(juce::Slider::rotarySliderOutlineColourId, panelLight);
    getLookAndFeel().setColour(juce::Slider::thumbColourId, gold);

    productLabel.setText("LIBERTY  /  ROMPLER", juce::dontSendNotification);
    productLabel.setFont(juce::Font(juce::FontOptions(26.0f, juce::Font::bold)));
    productLabel.setColour(juce::Label::textColourId, ice);
    addAndMakeVisible(productLabel);

    sectionLabel.setText("BIBLIOTHÈQUE SONORE", juce::dontSendNotification);
    sectionLabel.setFont(juce::Font(juce::FontOptions(14.0f, juce::Font::bold)));
    sectionLabel.setColour(juce::Label::textColourId, gold);
    addAndMakeVisible(sectionLabel);

    searchField.setTextToShowWhenEmpty("Rechercher un preset...", muted);
    searchField.onTextChange = [this] { rebuildPresetList(); };
    addAndMakeVisible(searchField);
    bankSelector.onChange = [this] {
        bankIndex = bankSelector.getSelectedItemIndex();
        rebuildCategoryList();
        rebuildPresetList();
    };
    addAndMakeVisible(bankSelector);
    categorySelector.onChange = [this] {
        category = categorySelector.getText();
        rebuildPresetList();
    };
    addAndMakeVisible(categorySelector);

    presetList.setModel(this);
    presetList.setColour(juce::ListBox::backgroundColourId, panel);
    presetList.setColour(juce::ListBox::outlineColourId, juce::Colours::transparentBlack);
    presetList.setRowHeight(44);
    addAndMakeVisible(presetList);

    presetLabel.setFont(juce::Font(juce::FontOptions(28.0f, juce::Font::bold)));
    presetLabel.setColour(juce::Label::textColourId, ice);
    addAndMakeVisible(presetLabel);
    statusLabel.setFont(juce::Font(juce::FontOptions(13.0f)));
    statusLabel.setColour(juce::Label::textColourId, muted);
    addAndMakeVisible(statusLabel);

    configureSlider(gainSlider, gainLabel, "NIVEAU", 0.0, 1.5, p.getControls().masterGain.load());
    configureSlider(attackSlider, attackLabel, "ATTAQUE", 0.0, 2.0, p.getControls().attackSeconds.load());
    configureSlider(releaseSlider, releaseLabel, "RELÂCHEMENT", 0.02, 5.0, p.getControls().releaseSeconds.load());
    gainSlider.onValueChange = [this] { processor.getControls().masterGain = (float)gainSlider.getValue(); };
    attackSlider.onValueChange = [this] { processor.getControls().attackSeconds = (float)attackSlider.getValue(); };
    releaseSlider.onValueChange = [this] { processor.getControls().releaseSeconds = (float)releaseSlider.getValue(); };

    rescanButton.onClick = [this] { processor.getLibrary().rescan(); rebuildBankList(); };
    folderButton.onClick = [this] {
        const auto folder = processor.getLibrary().getDirectory();
        folder.createDirectory();
        folder.revealToUser();
    };
    addAndMakeVisible(rescanButton);
    addAndMakeVisible(folderButton);
    rescanButton.setColour(juce::TextButton::buttonColourId, panelLight);
    folderButton.setColour(juce::TextButton::buttonColourId, panelLight);
    rescanButton.setColour(juce::TextButton::textColourOffId, ice);
    folderButton.setColour(juce::TextButton::textColourOffId, ice);

    keyboard.setAvailableRange(24, 96);
    keyboard.setKeyWidth(24.0f);
    addAndMakeVisible(keyboard);
    rebuildBankList();
}

void LibertyRomplerAudioProcessorEditor::configureSlider(juce::Slider& slider, juce::Label& label,
    const juce::String& name, double min, double max, double value) {
    slider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
    slider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 92, 23);
    slider.setRange(min, max, 0.001);
    slider.setValue(value, juce::dontSendNotification);
    slider.setColour(juce::Slider::textBoxTextColourId, ice);
    slider.setColour(juce::Slider::textBoxBackgroundColourId, panel);
    slider.setColour(juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
    addAndMakeVisible(slider);
    label.setText(name, juce::dontSendNotification);
    label.setJustificationType(juce::Justification::centred);
    label.setColour(juce::Label::textColourId, muted);
    addAndMakeVisible(label);
}

void LibertyRomplerAudioProcessorEditor::rebuildBankList() {
    const auto oldId = processor.getSelectedBankId();
    bankSelector.clear(juce::dontSendNotification);
    const auto& banks = processor.getLibrary().getBanks();
    int selected = 0;
    for (size_t i = 0; i < banks.size(); ++i) {
        bankSelector.addItem(banks[i].name, (int)i + 1);
        if (banks[i].id == oldId) selected = (int)i;
    }
    if (!banks.empty()) bankSelector.setSelectedItemIndex(selected, juce::dontSendNotification);
    bankIndex = banks.empty() ? -1 : selected;
    rebuildCategoryList();
    rebuildPresetList();
}
void LibertyRomplerAudioProcessorEditor::rebuildCategoryList() {
    categorySelector.clear(juce::dontSendNotification);
    categorySelector.addItem("Toutes", 1);
    const auto& banks = processor.getLibrary().getBanks();
    if (bankIndex >= 0 && bankIndex < (int)banks.size()) {
        juce::StringArray categories;
        for (const auto& p : banks[(size_t)bankIndex].presets)
            if (p.category.isNotEmpty()) categories.addIfNotAlreadyThere(p.category);
        categories.sort(true);
        for (auto& cat : categories) categorySelector.addItem(cat, categorySelector.getNumItems() + 1);
    }
    category = "Toutes";
    categorySelector.setSelectedId(1, juce::dontSendNotification);
}
void LibertyRomplerAudioProcessorEditor::rebuildPresetList() {
    visiblePresetIndices.clear();
    const auto& banks = processor.getLibrary().getBanks();
    if (bankIndex >= 0 && bankIndex < (int)banks.size()) {
        const auto& bank = banks[(size_t)bankIndex];
        for (size_t i = 0; i < bank.presets.size(); ++i) {
            const auto& p = bank.presets[i];
            if ((category == "Toutes" || p.category == category) &&
                (searchField.getText().isEmpty() || p.name.containsIgnoreCase(searchField.getText())))
                visiblePresetIndices.push_back((int)i);
        }
    }
    presetList.updateContent();
    presetList.repaint();
    updatePresetInfo();
}
int LibertyRomplerAudioProcessorEditor::getNumRows() { return (int)visiblePresetIndices.size(); }
void LibertyRomplerAudioProcessorEditor::paintListBoxItem(int row, juce::Graphics& g,
                                                          int width, int height, bool selected) {
    if (row < 0 || row >= (int)visiblePresetIndices.size()) return;
    const auto& banks = processor.getLibrary().getBanks();
    if (bankIndex < 0 || bankIndex >= (int)banks.size()) return;
    const auto& p = banks[(size_t)bankIndex].presets[(size_t)visiblePresetIndices[(size_t)row]];
    const bool active = processor.getSelectedBankId() == p.bankId && processor.getSelectedPresetId() == p.id;
    if (selected || active) {
        g.setColour(panelLight); g.fillRoundedRectangle(juce::Rectangle<float>(3.0f, 2.0f, (float)width - 6, (float)height - 4), 5.0f);
        g.setColour(gold); g.fillRoundedRectangle(4.0f, 4.0f, 3.0f, (float)height - 8, 1.5f);
    }
    g.setColour(ice); g.setFont(15.0f);
    g.drawText(p.name, 17, 5, width - 28, 22, juce::Justification::centredLeft);
    g.setFont(11.5f); g.setColour(muted);
    g.drawText(p.category, 17, 26, width - 28, 16, juce::Justification::centredLeft);
}
void LibertyRomplerAudioProcessorEditor::selectedRowsChanged(int row) {
    if (row < 0 || row >= (int)visiblePresetIndices.size()) return;
    const auto& banks = processor.getLibrary().getBanks();
    if (bankIndex < 0 || bankIndex >= (int)banks.size()) return;
    const auto& p = banks[(size_t)bankIndex].presets[(size_t)visiblePresetIndices[(size_t)row]];
    const auto status = processor.selectPreset(p.bankId, p.id);
    if (status.failed()) statusLabel.setText(status.getErrorMessage(), juce::dontSendNotification);
    else updatePresetInfo();
    presetList.repaint();
}
void LibertyRomplerAudioProcessorEditor::updatePresetInfo() {
    const auto name = processor.getSelectedPresetName();
    presetLabel.setText(name.isEmpty() ? "Aucun preset chargé" : name, juce::dontSendNotification);
    const auto* p = processor.getLibrary().find(processor.getSelectedBankId(), processor.getSelectedPresetId());
    statusLabel.setText(p ? (p->bankName + "   •   " + p->category + "   •   " +
                              juce::String((int)p->zones.size()) + " zone(s) multisample")
                          : "Installez une banque pour commencer.", juce::dontSendNotification);
}
void LibertyRomplerAudioProcessorEditor::paint(juce::Graphics& g) {
    g.fillAll(midnight);
    const auto w = getWidth(), h = getHeight();
    g.setColour(panel);
    g.fillRoundedRectangle(16.0f, 84.0f, (float)(w * 0.39f - 22), (float)(h - 225), 12.0f);
    g.fillRoundedRectangle((float)(w * 0.39f + 8), 84.0f, (float)(w * 0.61f - 24), (float)(h - 225), 12.0f);
    g.setColour(gold.withAlpha(0.75f));
    g.fillRect(20, 66, w - 40, 2);
    g.setColour(muted); g.setFont(12.0f);
    g.drawText("INSTRUMENT MULTISAMPLE  ·  VERSION PROTOTYPE 0.1", w - 390, 22, 370, 34,
               juce::Justification::centredRight);
    g.drawText("CLAVIER MIDI", 22, h - 129, 160, 22, juce::Justification::centredLeft);
    g.drawText("3 paramètres fonctionnels · banques externes · AU / VST3 / Standalone",
               (int)(w * 0.39f + 31), h - 151, (int)(w * 0.59f - 60), 20,
               juce::Justification::centredLeft);
}
void LibertyRomplerAudioProcessorEditor::resized() {
    const auto w = getWidth(), h = getHeight();
    const int left = 25, split = (int)(w * 0.39f), rightX = split + 28;
    productLabel.setBounds(22, 13, 450, 46);
    sectionLabel.setBounds(left, 100, split - 55, 24);
    bankSelector.setBounds(left, 133, split - 55, 34);
    searchField.setBounds(left, 179, split - 55, 34);
    categorySelector.setBounds(left, 224, split - 55, 32);
    presetList.setBounds(left, 266, split - 55, juce::jmax(32, h - 468));
    rescanButton.setBounds(left, h - 191, 105, 28);
    folderButton.setBounds(left + 113, h - 191, split - 168, 28);

    presetLabel.setBounds(rightX, 116, w - rightX - 35, 48);
    statusLabel.setBounds(rightX, 165, w - rightX - 35, 32);
    const int knobW = juce::jmin(168, (w - rightX - 36) / 3);
    const int x0 = rightX + 5;
    juce::Slider* knobs[] {&gainSlider, &attackSlider, &releaseSlider};
    juce::Label* labels[] {&gainLabel, &attackLabel, &releaseLabel};
    for (int i = 0; i < 3; ++i) {
        knobs[i]->setBounds(x0 + i * knobW, 240, knobW - 8, juce::jmax(88, juce::jmin(176, h - 410)));
        labels[i]->setBounds(x0 + i * knobW, 216, knobW - 8, 22);
    }
    keyboard.setBounds(22, h - 103, w - 44, 80);
}
