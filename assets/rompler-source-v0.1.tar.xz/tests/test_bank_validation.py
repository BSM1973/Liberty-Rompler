import copy
import json
import tempfile
import unittest
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
from validate_banks import check_root

BASE = Path(__file__).resolve().parents[1] / 'Banks'

class BankTests(unittest.TestCase):
    def test_factory_and_expansion(self):
        errors, bank_count, preset_count = check_root(BASE)
        self.assertEqual(errors, [])
        self.assertEqual(bank_count, 2)
        self.assertEqual(preset_count, 9)

    def test_bad_json_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / 'Broken'
            path.mkdir()
            (path / 'manifest.json').write_text('{bad', encoding='utf-8')
            errors, _, _ = check_root(Path(temp))
            self.assertTrue(errors)

    def test_path_traversal_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / 'Evil'
            path.mkdir()
            manifest = json.loads((BASE / 'Factory-Starter/manifest.json').read_text(encoding='utf-8'))
            manifest['presets'][0]['zones'][0]['file'] = '../../etc/passwd'
            manifest['presets'] = manifest['presets'][:1]
            (path / 'manifest.json').write_text(json.dumps(manifest), encoding='utf-8')
            errors, _, _ = check_root(Path(temp))
            self.assertTrue(any('unsafe sample path' in error for error in errors))

if __name__ == '__main__':
    unittest.main()
