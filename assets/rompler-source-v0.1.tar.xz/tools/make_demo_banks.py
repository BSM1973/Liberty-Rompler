#!/usr/bin/env python3
"""Generate 100% original, royalty-free synthetic ROMpler demo WAVs + manifest files.
Run from the repository root: python3 tools/make_demo_banks.py
Requires numpy only for this sound-generation step (not for the plugin itself).
"""
import json
import math
from pathlib import Path
import wave
import numpy as np

ROOT = Path(__file__).resolve().parents[1] / 'Banks'
RATE = 44100
SECONDS = 3.2
N = int(RATE * SECONDS)
T = np.arange(N, dtype=np.float64) / RATE
LOOP_START = int(0.9 * RATE)
LOOP_END = int(2.8 * RATE)
FADE = int(0.13 * RATE)


def make_wave(kind: str, note: int, variation: int) -> np.ndarray:
    freq = 440.0 * (2.0 ** ((note - 69) / 12.0))
    phase = 2 * np.pi * freq * T
    rng = np.random.default_rng(20261109 + 211 * variation + note)
    if kind == 'pad':
        sig = (0.56 * np.sin(phase) + 0.25 * np.sin(2 * phase + 0.4) +
               0.15 * np.sin(3 * phase - 0.2) + 0.09 * np.sin(phase * 1.003))
        sig *= np.minimum(1.0, T / 0.7)
    elif kind == 'glass':
        sig = (0.62 * np.sin(phase) + 0.17 * np.sin(2.52 * phase) +
               0.12 * np.sin(4.13 * phase))
        sig *= (0.55 + 0.45 * np.exp(-T * 1.4))
    elif kind == 'bass':
        sig = (0.65 * np.sin(phase) + 0.24 * np.sin(2 * phase) +
               0.09 * np.sin(3 * phase) + 0.05 * np.sin(4 * phase))
    elif kind == 'lead':
        sig = sum(np.sin(k * phase) / (k ** 1.5) for k in range(1, 12))
        sig = np.tanh(sig * 1.25)
    elif kind == 'pluck':
        sig = (0.55 * np.sin(phase) + 0.19 * np.sin(2 * phase) +
               0.14 * np.sin(3 * phase) + 0.06 * np.sin(5 * phase))
        sig *= (0.40 + 0.60 * np.exp(-T * 2.3))
    elif kind == 'choir':
        sig = (0.48 * np.sin(phase) + 0.28 * np.sin(2 * phase + 0.25) +
               0.18 * np.sin(3 * phase + 1.5) + 0.08 * np.sin(4 * phase))
        sig *= (0.78 + 0.22 * np.sin(2 * np.pi * 0.35 * T))
    elif kind == 'texture':
        noise = rng.normal(0, 1, N)
        smooth = np.convolve(noise, np.ones(90) / 90.0, mode='same')
        sig = 0.67 * np.sin(phase) + 0.25 * np.sin(1.501 * phase) + 0.15 * smooth
    else:
        raise ValueError(kind)
    sig *= np.minimum(1.0, T / 0.012)  # no initial click
    # Crossfade the last part of the sustain loop into its beginning for glitch-free looping.
    ramp = np.linspace(0.0, 1.0, FADE, endpoint=True)
    tail = sig[LOOP_END - FADE:LOOP_END].copy()
    head = sig[LOOP_START:LOOP_START + FADE]
    sig[LOOP_END - FADE:LOOP_END] = tail * (1.0 - ramp) + head * ramp
    return (np.clip(sig * 0.47, -1.0, 1.0) * 32767).astype('<i2')


def save_wav(path: Path, kind: str, note: int, variation: int):
    path.parent.mkdir(parents=True, exist_ok=True)
    pcm = make_wave(kind, note, variation)
    with wave.open(str(path), 'wb') as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(RATE)
        wav.writeframes(pcm.tobytes())


def preset(id: str, name: str, category: str, kind: str, variation: int):
    zones = []
    for root_note, lo, hi in ((48, 24, 59), (72, 60, 96)):
        filename = f'Samples/{kind}_{variation}_n{root_note}.wav'
        zones.append({
            'file': filename, 'root_note': root_note,
            'low_note': lo, 'high_note': hi,
            'low_velocity': 1, 'high_velocity': 127,
            'loop_start': LOOP_START, 'loop_end': LOOP_END,
            'gain': 0.58
        })
    return {'id': id, 'name': name, 'category': category, 'zones': zones}


def generate_bank(folder: str, bank_id: str, name: str, recipes: list):
    target = ROOT / folder
    target.mkdir(parents=True, exist_ok=True)
    presets = []
    created = set()
    for index, (id, name_p, category, kind) in enumerate(recipes):
        variant = index + (10 if bank_id != 'factory-starter' else 0)
        item = preset(id, name_p, category, kind, variant)
        for z in item['zones']:
            if z['file'] not in created:
                save_wav(target / z['file'], kind, z['root_note'], variant)
                created.add(z['file'])
        presets.append(item)
    manifest = {
        'format': 'liberty-rompler-bank-v1', 'id': bank_id,
        'name': name, 'version': '0.1.0',
        'license_mode': 'demo-unprotected',
        'presets': presets
    }
    (target / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return len(presets), len(created)


def main():
    stats1 = generate_bank('Factory-Starter', 'factory-starter', 'Factory Starter', [
        ('aurora-pad', 'Aurora Pad', 'Pads', 'pad'),
        ('crystal-keys', 'Crystal Keys', 'Keys', 'glass'),
        ('sub-current', 'Sub Current', 'Bass', 'bass'),
        ('signal-lead', 'Signal Lead', 'Leads', 'lead'),
        ('amber-pluck', 'Amber Pluck', 'Plucks', 'pluck'),
        ('human-atmos', 'Human Atmos', 'Textures', 'choir'),
    ])
    stats2 = generate_bank('Expansion-Demo', 'expansion-demo', 'Expansion Demo — NON PROTÉGÉE', [
        ('eclipse-pad', 'Eclipse Pad', 'Pads', 'texture'),
        ('silver-choir', 'Silver Choir', 'Textures', 'choir'),
        ('titan-bass', 'Titan Bass', 'Bass', 'bass'),
    ])
    print('Factory Starter:', stats1, 'presets / samples')
    print('Expansion Demo:', stats2, 'presets / samples')
    print('IMPORTANT: this demonstration contains no licence / encryption system.')

if __name__ == '__main__':
    main()
