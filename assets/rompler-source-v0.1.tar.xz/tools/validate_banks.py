#!/usr/bin/env python3
"""Offline format-1 bank validation, with strict path handling.
Usage: python3 tools/validate_banks.py [Banks/]
"""
import json
import re
import sys
from pathlib import Path
import wave

ID = re.compile(r'^[a-zA-Z0-9_-]{1,80}$')


def check_root(root: Path):
    errors = []
    bank_ids = set()
    if not root.is_dir():
        return [f'Banks directory does not exist: {root}'], 0, 0
    banks, presets = 0, 0
    for folder in sorted(root.iterdir()):
        if not folder.is_dir() or not (folder / 'manifest.json').exists():
            continue
        try:
            manifest = json.loads((folder / 'manifest.json').read_text(encoding='utf-8'))
        except (ValueError, OSError) as exc:
            errors.append(f'{folder.name}: invalid JSON ({exc})')
            continue
        if manifest.get('format') != 'liberty-rompler-bank-v1':
            errors.append(f'{folder.name}: invalid manifest format')
            continue
        bid = manifest.get('id', '')
        if not isinstance(bid, str) or not ID.fullmatch(bid) or bid in bank_ids:
            errors.append(f'{folder.name}: invalid or duplicate bank ID')
            continue
        bank_ids.add(bid)
        bank_presets = manifest.get('presets', [])
        if not isinstance(bank_presets, list) or not 1 <= len(bank_presets) <= 256:
            errors.append(f'{folder.name}: expected 1..256 presets')
            continue
        banks += 1
        names = set()
        for patch in bank_presets:
            presets += 1
            patch_id = patch.get('id', '')
            if not isinstance(patch_id, str) or not ID.fullmatch(patch_id) or patch_id in names:
                errors.append(f'{bid}: invalid or duplicated preset ID {patch_id!r}')
            names.add(patch_id)
            zones = patch.get('zones', [])
            if not isinstance(zones, list) or not 1 <= len(zones) <= 32:
                errors.append(f'{bid}/{patch_id}: expected 1..32 zones')
                continue
            for index, zone in enumerate(zones):
                ident = f'{bid}/{patch_id}/zone{index}'
                name = zone.get('file', '')
                if not isinstance(name, str) or '\\' in name or not name or Path(name).is_absolute() or '..' in Path(name).parts:
                    errors.append(f'{ident}: unsafe sample path')
                    continue
                file = folder / name
                try:
                    resolved = file.resolve(strict=True)
                except (OSError, FileNotFoundError):
                    errors.append(f'{ident}: missing sample: {name}')
                    continue
                if not resolved.is_relative_to(folder.resolve()):
                    errors.append(f'{ident}: sample path escapes bank')
                    continue
                for key, lo, hi in [('root_note', 0, 127), ('low_note', 0, 127),
                                    ('high_note', 0, 127), ('low_velocity', 1, 127),
                                    ('high_velocity', 1, 127)]:
                    v = zone.get(key)
                    if not isinstance(v, int) or not lo <= v <= hi:
                        errors.append(f'{ident}: {key} must be {lo}..{hi}')
                if zone.get('low_note', 0) > zone.get('high_note', 127) or zone.get('low_velocity', 1) > zone.get('high_velocity', 127):
                    errors.append(f'{ident}: invalid MIDI range')
                if not isinstance(zone.get('gain'), (int, float)) or not 0 <= zone['gain'] <= 4:
                    errors.append(f'{ident}: invalid gain')
                try:
                    with wave.open(str(resolved), 'rb') as wav:
                        frames = wav.getnframes()
                        if wav.getnchannels() not in (1, 2) or wav.getsampwidth() != 2 or wav.getframerate() < 22050:
                            errors.append(f'{ident}: expected mono/stereo 16-bit PCM WAV (>=22050 Hz)')
                        if frames < 2 or frames > wav.getframerate() * 20:
                            errors.append(f'{ident}: unsupported sample length')
                        loop_start, loop_end = zone.get('loop_start', -1), zone.get('loop_end', -1)
                        if loop_start >= 0 and not 0 <= loop_start + 10 < loop_end <= frames:
                            errors.append(f'{ident}: invalid loop range')
                except (wave.Error, OSError, EOFError) as exc:
                    errors.append(f'{ident}: damaged WAV ({exc})')
    return errors, banks, presets

if __name__ == '__main__':
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1] / 'Banks'
    errors, banks, presets = check_root(root)
    print(f'Checked: {banks} banks, {presets} presets')
    if errors:
        for error in errors: print('ERROR:', error)
        sys.exit(1)
    print('PASS: all bank manifests, sample paths, and WAV files verified')
